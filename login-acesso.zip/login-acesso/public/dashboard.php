<?php
require_once 'verifica_sessao.php';
$usuarioLogado = $_SESSION['user']['usuario'] ?? 'Usuário';
$perfilLogado  = $_SESSION['user']['perfil']  ?? 'user';
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Dashboard • AlugaFácil</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../assets/css/app.css">
</head>
<body class="bg">
  <header class="topbar">
    <div class="brand">AlugaFácil</div>
    <div class="user">
      <span>Olá, <strong><?= htmlspecialchars($usuarioLogado) ?></strong></span>
      <a class="button button-danger" href="logout.php" title="Sair">Sair</a>
    </div>
  </header>

  <main class="content">
    <section class="hero">
      <h1>Dashboard</h1>
      <p>Escolha uma ação abaixo para começar. (Botões fictícios)</p>
    </section>

    <section class="grid">
      <article class="card">
        <h2>Cadastrar CNH</h2>
        <p>Armazene e valide os dados de habilitação do cliente.</p>
        <button class="button" type="button" onclick="void(0)">Cadastrar CNH</button>
      </article>

      <article class="card">
        <h2>Alugar Carro</h2>
        <p>Inicie um novo contrato de locação rapidamente.</p>
        <button class="button" type="button" onclick="void(0)">Alugar Carro</button>
      </article>

      <article class="card">
        <h2>Perfil</h2>
        <p>Veja e atualize suas informações de acesso.</p>
        <button class="button" type="button" onclick="void(0)">Perfil</button>
      </article>

      <?php if ($perfilLogado === 'admin'): ?>
      <article class="card">
        <h2>Listar Usuários</h2>
        <p>Visualize todos os usuários cadastrados no sistema.</p>
        <a class="button" href="listar_usuarios.php">Listar Usuários</a>
      </article>
      <?php endif; ?>
    </section>
  </main>

  <footer class="footer">
    © <?= date('Y') ?> AlugaFácil — Todos os direitos reservados.
  </footer>
</body>
</html>
