<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <title>Acesso Negado</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../assets/css/app.css">
</head>
<body class="bg-center">
  <div class="denied-box">
    <h1>Acesso Negado</h1>
    <p>Você precisa estar logado para acessar esta página.</p>
    <a href="index.php" class="button">Voltar para Login</a>
  </div>
</body>
</html>
